import java.util.*;

public class Withdraw {
    public static void main(String[] args) {
    }
}
